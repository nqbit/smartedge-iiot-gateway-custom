import os
import sys
from setuptools import setup

setup(
    name="iotconnect-sdk-simulator-py2.7",
    version="2.0",
    python_requires='~=2.7',
    description='IOT Connect DPS version 2.0',
    packages=["iotconnect", "iotconnect.client", "iotconnect.common", "iotconnect.packages", "iotconnect.packages.iothub_device_client","iotconnect.packages.provisioning_device_client"],
    install_requires=["paho-mqtt","wheel"],
    package_data={'iotconnect': ['assets/*.*']},
    platforms=['Linux', 'Mac OS X', 'Win'],
    zip_safe=False,
    classifiers=[
        "Programming Language :: Python :: 2.7",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ],
)