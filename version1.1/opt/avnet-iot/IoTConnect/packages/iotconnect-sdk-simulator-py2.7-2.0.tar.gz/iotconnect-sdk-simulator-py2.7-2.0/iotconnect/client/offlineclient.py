import sys, os
import json
import threading

class offlineclient:
    _data_path = ""
    _sdk_config = None
    _lock = False
    
    def Send(self, data):
        try:
            _data = json.dumps(data) + "\n"
            if self._data_path:
                with open(self._data_path, "a") as dfile:
                    dfile.write(_data)
        except Exception as ex:
            print("publish_offline : " + ex.message)
    
    def data_exist(self):
        try:
            _data = None
            with open(self._data_path, "r") as dfile:
                _data = dfile.read()
            
            if _data == None or _data == "":
                return False
            else:
                return True
        except Exception as ex:
            return False
    
    def send_back_to_client(self):
        try:
            _data = None
            with open(self._data_path, "r") as dfile:
                _data = dfile.read()
            
            if _data != None:
                _data = _data.split("\n")
            
            if len(_data) > 0:
                _rData = []
                for obj in _data:
                    if obj != "" and self.sendBackToClient(json.loads(obj)) == False:
                        _rData.append(obj)
                
                _flag = "a"
                if len(_rData) > 0:
                    _rData = "\n".join(_rData)
                else:
                    _flag = "w"
                    _rData = ""
                
                with open(self._data_path, _flag) as dfile:
                    dfile.write(_rData)
                
                self._lock = False
        except Exception as ex:
            print("send_back_to_client : " + ex.message)
            self._lock = False
    
    def PublishData(self):
        try:
            if self._lock == False:
                if self.data_exist():
                    self._lock = True
                    self.event_call("PUBDATA", "send_back_to_client",())
        except Exception as ex:
            print("PublishData : ", ex.message)
    
    def event_call(self, name, taget, arg):
        try:
            _thread = threading.Thread(target=getattr(self, taget), args=arg)
            _thread.daemon = True
            _thread.setName(name)
            _thread.start()
        except Exception as ex:
            print("event_call : " + ex.message)
    
    def __init__(self, sdk_config, sendBackToClient):
        try:
            self._sdk_config = sdk_config
            
            if self._sdk_config == None:
                raise Exception("SDK Configration not found!")
            
            self._data_path = os.path.join(sys.path[0], 'sensor_data.txt')

            #self._data_path = os.path.abspath(os.path.dirname(__file__) + "/../") + "\\data.txt"
            self.sendBackToClient = sendBackToClient
        except Exception as ex:
            print("Offline Client Init : " + ex.message)
