import sys, os
import httplib, json
import os.path
import urllib2
import copy
import time
import threading

from urlparse import urlparse
from datetime import datetime
from threading import Timer

from iotconnect.client.mqttclient import mqttclient
from iotconnect.client.httpclient import httpclient
from iotconnect.client.dpsclient import dpsclient
from iotconnect.client.offlineclient import offlineclient

from iotconnect.common.DataEvaluation import DataEvaluation
from iotconnect.common.RuleEvaluation import RuleEvaluation
from iotconnect.common.RepeatingTimer import RepeatingTimer

CONFIG_PATH = "assets/config.json"

MSGTYPE = {
    "RPT": 0,
    "FLT": 1,
    "RPTEDGE": 2,
    "RMEdge": 3,
    "LOG" : 4,
	"ACK" : 5,
	"OTA" : 6,
    "DEVICE_CREATED": 9,
    "DEVICE_CONNECTED": 10,
    "FIRMWARE": 11
}
RCCode = {
    "OK": 0,
    "DEV_NOT_REG": 1,
    "AUTO_REG": 2,
    "DEV_NOT_FOUND": 3,
    "DEV_INACTIVE": 4,
    "OBJ_MOVED": 5,
    "CPID_NOT_FOUND": 6
}
CMDTYPE = {
    "DCOMM": "0x01",
    "FIRMWARE": "0x02",
    "U_ATTRIBUTE": "0x10",
    "U_SETTING": "0x11",
    "U_PROTOCOL": "0x12",
    "U_DEVICE": "0x13",
    "U_RULE": "0x15",
    "SYNC": "sync",
    "RESETPWD": "resetpwd",
    "UCART": "updatecrt",
}
OPTION = {
    "attribute": "att",
    "setting": "s",
    "protocol": "p",
    "device": "d",
    "sdkConfig": "sc",
    "rule": "r"
}

class IoTConnectSDK:
    _config = None
    _cpId = None
    _uniqueId = None
    _listner_callback = None
    _data_json = None
    _client = None
    _process_start = False
    _base_url = ""
    _thread = None
    _ruleEval = None
    _offlineClient = None
    _lock = None
    
    def get_config(self):
        try:
            self._config = None
            _path = os.path.abspath(os.path.dirname(__file__))            
            _config_path = os.path.join(_path, CONFIG_PATH)
            with open(_config_path) as config_file:
                self._config = json.loads(config_file.read())
        except Exception as ex:
            print("get_config : " + ex.message)
    
    def get_properties(self):
        try:
            if self._config:
                _properties = None
                _path = os.path.join(sys.path[0], 'properties.json')
                if _path != None and _path != "" and os.path.isfile(_path):
                    with open(_path) as properties_file:
                        _properties = json.loads(properties_file.read())

                if _properties == None:
                    raise Exception("SDK properties file not found!")
                
                if _properties != None:
                    for prop in _properties:
                        self._config[prop] = _properties[prop]
                
        except Exception as ex:
            print("get_properties : " + ex.message)
    
    def get_base_url(self, cpId):
        try:
            base_url = self._config["sdk_base_url"]
            base_url = base_url.replace("{cpid}", cpId)
            base_url = base_url.replace("{sdk_lang}", self._config["sdk_lang"])
            base_url = base_url.replace("{sdk_version}", self._config["sdk_version"])
            base_url = base_url.replace("{env}", self._config["env"])
            res = urllib2.urlopen(base_url).read()
            data = json.loads(res)
            return data["baseUrl"]
        except Exception as ex:
            print("get_base_url : " + ex.message)
            return None
    
    def post_call(self, url, body):
        try:
            parsed_uri = urlparse(url)
            scheme = parsed_uri.scheme
            host = parsed_uri.hostname
            port = parsed_uri.port
            path = parsed_uri.path

            #print("Base URL : " + str(url))
            #print("Body : " + body)

            if port == None:
                if scheme == "http":
                    conn = httplib.HTTPConnection(host)
                else:
                    conn = httplib.HTTPSConnection(host)
            else:
                if scheme == "http":
                    conn = httplib.HTTPConnection(host, port)
                else:
                    conn = httplib.HTTPSConnection(host, port)

            conn.request("POST", path, body, {
                         "Content-type": "application/json", "Accept": "application/json"})
            response = conn.getresponse()
            data = json.loads(response.read())
            conn.close()
            return data
        except:
            return None
    
    def onMessage(self, msg):
        try:
            if msg == None or msg == "":
                return
            
            if len(msg.items()) == 0:
                return
            
            print(json.dumps(msg))
            if msg["cmdType"] == CMDTYPE["U_ATTRIBUTE"]:
                threading.Thread(target = self.reset_process_sync, args = ["attribute"]).start()
            elif msg["cmdType"] == CMDTYPE["U_SETTING"]:
                threading.Thread(target = self.reset_process_sync, args = ["setting"]).start()
            elif msg["cmdType"] == CMDTYPE["U_PROTOCOL"]:
                threading.Thread(target = self.reset_process_sync, args = ["protocol"]).start()
            elif msg["cmdType"] == CMDTYPE["U_DEVICE"]:
                threading.Thread(target = self.reset_process_sync, args = ["device"]).start()
            elif msg["cmdType"] == CMDTYPE["U_RULE"]:
                threading.Thread(target = self.reset_process_sync, args = ["rule"]).start()
            elif msg["cmdType"] == CMDTYPE["SYNC"]:
                threading.Thread(target = self.reset_process_sync, args = ["all"]).start()
            elif msg["cmdType"] == CMDTYPE["RESETPWD"]:
                threading.Thread(target = self.reset_process_sync, args = ["protocol"]).start()
            elif msg["cmdType"] == CMDTYPE["UCART"]:
                threading.Thread(target=self.update_crt, args=()).start()
            elif msg["cmdType"] == CMDTYPE["DCOMM"] or msg["cmdType"] == CMDTYPE["FIRMWARE"]:
                if self.listner_callback != None:
                    self.listner_callback(msg)
            else:
                print("Message : " + json.dumps(msg))
        except Exception as ex:
            print("onMessage : ", ex.message)
    
    def onMessageSend(self, message_type, data):
        try:
            if message_type == None and data:
                return
            
            _data = self._data_template
            if MSGTYPE["DEVICE_CREATED"] == message_type:
                _data["mt"] = MSGTYPE["DEVICE_CREATED"]
                _data["d"].append(data)
                self.send_msg_to_broker("DPS", _data)
            
            if MSGTYPE["DEVICE_CONNECTED"] == message_type:
                _data["mt"] = MSGTYPE["DEVICE_CONNECTED"]
                _data["d"].append(data)
                self.send_msg_to_broker("DPS", _data)
            
        except Exception as ex:
            print("onMessageSend : ", ex.message)
    
    def init_protocol(self, protocol_cofig):
        try:
            if protocol_cofig == None:
                raise Exception("protocol settings not found!")
            
            if self._client != None:
                self._client = None
            
            auth_type = self._data_json['at']
            if auth_type == 4: #DPS Client if Auth type TPM
                name = "dps"
            else:
                name = protocol_cofig["n"]
                       
            if name == "mqtt":
                if self._client == None:
                    self._client = mqttclient(auth_type, protocol_cofig, self._config, self.onMessage)
                else:
                    self._client.ResetConfig(auth_type, protocol_cofig)
            elif name == "http" or name == "https":
                if self._client == None:
                    self._client = httpclient(protocol_cofig, self._config)
                else:
                    self._client.ResetConfig(protocol_cofig)
            elif name == "dps":
                if self._client == None:
                    self._client = dpsclient(auth_type, protocol_cofig, self._config, self.onMessage, self.onMessageSend)
                else:
                    self._client.ResetConfig(protocol_cofig)
            else:
                self._client = None

            if self._client:
                if self._client.isConnected == False:
                    raise Exception()
                else:
                    print("Protocol Initialized...")

        except Exception as ex:
            raise Exception("Protocol Initialized Failed...")
    
    def process_sync(self, option):
        try:
            self._process_start = False
            # Pre Process
            self.clear_object(option)
            # --------------------------------    
            url = self._base_url
            if url == None: 
                raise Exception("Base url not found!")
            
            req_json = {}
            req_json["uniqueId"] = self._uniqueId
            req_json["cpId"] = self._cpId
            req_json["option"] = { }
            if option == "all":
                req_json["option"]["attribute"] = True
                req_json["option"]["setting"] = True
                req_json["option"]["protocol"] = True
                req_json["option"]["device"] = True
                req_json["option"]["sdkConfig"] = True
                req_json["option"]["rule"] = True
            else:
                req_json["option"][option] = True
            
            body = json.dumps(req_json)
            response = self.post_call(url + 'sync', body)

            if response == None:
                return
            
            response = response["d"]
            if response["rc"] != RCCode["OK"]:
                if option == "all":
                    print("Response Code : " + str(response["rc"]))
                    return
                else:
                    threading.Thread(target = self.reset_process_sync, args = [option]).start()
                    return
            else:
                #print(json.dumps(response))
                # --------------------------------
                if option == "all":
                    self._data_json = response
                else:
                    key = OPTION[option]
                    if self._data_json and self.has_key(self._data_json, key):
                        self._data_json[key] = response[key]
                    print("\n" + option + " updated sucessfully...")
                
                if option == "all" or option == "attribute":
                    for attr in self.attributes:
                        attr["evaluation"] = DataEvaluation(self.isEdge, attr, self.send_edge_data)

                if option == "all" or option == "protocol":
                    key = OPTION["protocol"]
                    self.init_protocol(self._data_json[key])
                
                self._process_start = True
        except Exception as ex:
            raise Exception(ex.message)
    
    def SendData(self, jsonArray):
        try:
            if self._process_start == False:
                return

            if self.devices is None:
                print("Error: Empty Devices")
                return

            if self.attributes is None:
                print("Error: Empty Attributes")
                return        
            #--------------------------------
            rul_data = []
            rpt_data = self._data_template
            flt_data = self._data_template
            for obj in jsonArray:
                uniqueId = obj["uniqueId"]
                time = obj["time"]
                sensorData = obj["data"]
                for d in self.devices:
                    if d["id"] == uniqueId:
                        r_device = {
                            "id": uniqueId,
                            "dt": time,
                            "d": [],
                            "tg": d["tg"]
                        }
                        f_device = copy.deepcopy(r_device)
                        r_attr_s = {}
                        f_attr_s = {}
                        for attr in self.attributes:
                            if attr["p"] == "" and self.has_key(attr, "evaluation"):
                                evaluation = attr["evaluation"]
                                for dObj in attr["d"]:
                                    if self.has_key(sensorData, dObj["ln"]):
                                        value = sensorData[dObj["ln"]]
                                        row_data = evaluation.process_data(dObj, attr["p"], value)
                                        if row_data and self.has_key(row_data, "RPT"):
                                            for key, value in row_data["RPT"].iteritems():
                                                r_attr_s[key] = value
                                        if row_data and self.has_key(row_data, "FLT"):
                                            for key, value in row_data["FLT"].iteritems():
                                                f_attr_s[key] = value

                                data = evaluation.get_rule_data()
                                if data != None:
                                    rul_data.append(data)
                            
                            elif attr["p"] != "" and self.has_key(attr, "evaluation") and self.has_key(sensorData, attr["p"]) == True:
                                evaluation = attr["evaluation"]
                                for dObj in attr["d"]:
                                    if self.has_key(sensorData[attr["p"]], dObj["ln"]):
                                        value = sensorData[attr["p"]][dObj["ln"]]
                                        row_data = evaluation.process_data(dObj, attr["p"], value)
                                        if row_data and self.has_key(row_data, "RPT"):
                                            if self.has_key(r_attr_s, attr["p"]) == False:
                                                r_attr_s[attr["p"]] = {}
                                            for key, value in row_data["RPT"].iteritems():
                                               r_attr_s[attr["p"]][key] = value
                                            
                                        if row_data and self.has_key(row_data, "FLT"):
                                            if self.has_key(f_attr_s, attr["p"]) == False:
                                                f_attr_s[attr["p"]] = {}
                                            for key, value in row_data["FLT"].iteritems():
                                               f_attr_s[attr["p"]][key] = value

                                data = evaluation.get_rule_data()
                                if data != None:
                                    rul_data.append(data)
                            #--------------------------------
                        #--------------------------------
                        if len(r_attr_s.items()) > 0:
                            r_device["d"].append(r_attr_s)
                            rpt_data["d"].append(r_device)
                        
                        if len(f_attr_s.items()) > 0:
                            f_device["d"].append(f_attr_s)
                            flt_data["d"].append(f_device)
            #--------------------------------
            if len(rpt_data["d"]) > 0:
                rpt_data["mt"] = MSGTYPE["RPT"]
                self.send_msg_to_broker("RPT", rpt_data)
            
            if len(flt_data["d"]) > 0:
                flt_data["mt"] = MSGTYPE["FLT"]
                self.send_msg_to_broker("FLT", flt_data)
            #--------------------------------
            if self.isEdge and self.hasRules and len(rul_data) > 0:
                for rule in self.rules:
                    self._ruleEval.evalRules(rule, rul_data)  
        except Exception as ex:
            print("SendData : ", ex.message)
    
    def SendACK(self, msgType, data):
        try:
            if data == None:
                return
            
            if len(data.items()) == 0:
                return
            
            if msgType == None and msgType not in [11]:
                return
            
            template = self._data_template
            template["mt"] = msgType
            template["d"] = []
            template["d"].append({
                "id" : self._uniqueId,
                "d" : [data]
            })
            self.send_msg_to_broker("FW", template)
        except Exception as ex:
            print("send d2c data : ", ex.message)
    
    def send_edge_data(self, data):
        try:
            template = self._data_template
            template["mt"] = MSGTYPE["RPTEDGE"]
            for d in self.devices:
                device = {
                    "id": d["id"],
                    "dt": self._timestamp,
                    "d": []
                }
                device["d"].append(data)
                template["d"].append(device)
            
            self.send_msg_to_broker("RPTEDGE", template)
        except Exception as ex:
            print("send_edge_data : ", ex.message)
    
    def send_rule_data(self, data, rule):
        try:
            template = self._data_template
            template["mt"] = MSGTYPE["RMEdge"]
            for d in self.devices:
                device = {
                    "ui": d["id"],
                    "dt": self._timestamp,                    
                    "d": data,
                    "g": rule["g"],
                    "con": rule["con"],
                    "es": rule["es"]
                }
                template["d"].append(device)
            
            self.send_msg_to_broker("RMEdge", template)
        except Exception as ex:
            print("send_rule_data : ", ex.message)
    
    def send_msg_to_broker(self, msgType, data):
        try:
            self._lock.acquire()
            #print(json.dumps(data))
            #return
            _Online = False
            if self._client:
                _Online = self._client.Send(data)
            
            if _Online:
                if msgType == "RPTEDGE":
                    print("\nPublish edge data sucessfully...")
                elif msgType == "RMEdge":
                    print("\nPublish rule matched data sucessfully...")
                elif msgType == "CMD":
                    print("\nPublish Command data sucessfully...")
                elif msgType == "DPS":
                    pass
                elif msgType == "FW":
                    print("\nPublish Firmware data sucessfully...")
                    #print(json.dumps(data))
                else:
                    print("\npublish data sucessfully...")
            
            if _Online == False:
                self._offlineClient.Send(data)
            else:
                self._offlineClient.PublishData()
            self._lock.release()
        except Exception as ex:
            print("send_msg_to_broker : ", ex.message)
            self._lock.release()
    
    def send_offline_msg_to_broker(self, data):
        try:
            _Online = False
            if self._client and self._client.name == "mqtt":
                _Online = self._client.Send(data)
            if self._client and self._client.name == "dps":
                _Online = self._client.SendOfflineData(data)    
            return _Online
        except Exception as ex:
            print("send_offline_msg_to_broker : ", ex.message)
    
    def command_sender(self, command_text):
        try:
            template = self._command_template
            template["command"] = command_text
            if self.listner_callback != None:
                    self.listner_callback(template)
        except Exception as ex:
            print("command_sender : " + ex.message)
    
    def clear_object(self, option):
        try:
            if option == "all" or option == "attribute":
                for attr in self.attributes:
                    if self.has_key(attr, "evaluation"):
                        attr["evaluation"].destroyed()
                        del attr["evaluation"]
            #if option == "all" or option == "protocol":
            #    if self._client and self._client.Disconnect:
            #            self._client.Disconnect()
                
        except Exception as ex:
            print("clear_object : " + ex.message)
    
    def reset_process_sync(self, option):
        try:
            self.process_sync(option)
        except Exception as ex:
            print("reset_process_sync : " + ex.message)
    
    def reset_password(self):
        try:
            pass
        except Exception as ex:
            print("reset_password : " + ex.message)
    
    def update_crt(self):
        try:
            pass
        except Exception as ex:
            print("update_cert : " + ex.message)
    
    def event_call(self, name, taget, arg):
        try:
            _thread = threading.Thread(target=getattr(self, taget), args=arg)
            _thread.daemon = True
            _thread.setName(name)
            _thread.start()
        except Exception as ex:
            print("event_call : " + ex.message)
    
    def GetDevices(self):
        try:
            data = []
            for dObj in self.devices:
                tg = dObj["tg"]
                dtObj = {
                    "id": dObj["id"],
                    "attr": []
                }
                for aObj in self.attributes:
                    if aObj["p"] == "" and aObj["tg"] == "":
                        atObj = {
                            "p": aObj["p"],
                            "dt": aObj["dt"],
                            "tg": aObj["tg"],
                            "d": []
                        }
                        for pObj in aObj["d"]:
                            if tg == pObj["tg"]:
                                ptObj = {
                                    "ln": pObj["ln"],
                                    "dt": pObj["dt"],
                                    "dv": pObj["dv"],
                                    "tg": pObj["tg"],
                                }
                                atObj["d"].append(ptObj)
                        if len(atObj["d"]) > 0:
                            dtObj["attr"].append(atObj)
                    else:
                        if aObj["p"] != "" and tg == aObj["tg"]:
                            atObj = {
                                "p": aObj["p"],
                                "dt": aObj["dt"],
                                "tg": aObj["tg"],
                                "d": []
                            }
                            for pObj in aObj["d"]:
                                ptObj = {
                                    "ln": pObj["ln"],
                                    "dt": pObj["dt"],
                                    "dv": pObj["dv"],
                                    "tg": pObj["tg"],
                                }
                                atObj["d"].append(ptObj)
                            if len(atObj["d"]) > 0:
                                dtObj["attr"].append(atObj)
                if len(dtObj["attr"]) > 0:
                    data.append(dtObj)
            return data
        except Exception as ex:
            print("GetAttributes : " + ex.message)
    
    def GetAttributes(self):
        try:
            aData = []
            for attr in self.attributes:
                aObj = {
                    "p": attr["p"],
                    "dt": attr["dt"],
                    "tg": attr["tg"],
                    "d": []
                }
                for data in attr["d"]:
                    dObj = {
                        "ln": data["ln"],
                        "dt": data["dt"],
                        "dv": data["dv"],
                        "tg": data["tg"],
                    }
                    aObj["d"].append(dObj)
                aData.append(aObj)
            return aData
        except Exception as ex:
            print("GetAttributes : " + ex.message)
    
    def has_key(self, data, key):
        try:
            return data.has_key(key)
        except Exception as ex:
            print("has_key : " + ex.message)
            return False
    
    @property
    def isEdge(self):
        try:
            if self._data_json != None and self.has_key(self._data_json, "ee") and self._data_json["ee"] != None:
                return (self._data_json["ee"] == 1)
            else:
                return False
        except:
            return False
    
    @property
    def hasRules(self):
        try:
            key = OPTION["rule"]
            if self._data_json != None and self.has_key(self._data_json, key) and self._data_json[key] != None:
                return len(self._data_json[key]) > 0
            else:
                return False
        except:
            return False
    
    @property
    def _timestamp(self):
        return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z")
    
    @property
    def _data_template(self):
        try:
            data = {
                "cpId": "",
                "t": "",
                "mt": "",
                "d": [],
                "dtg" : "",
                "sdk": {
                    "l": self._config["sdk_lang"],
                    "v": self._config["sdk_version"],
                    "e": self._config["env"]
                }
            }
            data["t"] = self._timestamp
            if self._data_json != None:
                data["cpId"] = self._data_json["cpId"]
                data["dtg"] = self._data_json["dtg"]
            return data
        except:
            return None
    
    @property
    def _command_template(self):
        try:
            data = {
                "cpId": "",
                "guid": "",
                "uniqueId": "",
                "command": "",
                "ack" : False,
                "ackId": None,
                "cmdType": CMDTYPE["DCOMM"]
            }
            if self._data_json != None:
                data["cpId"] = self._data_json["cpId"]
                for d in self.devices:
                    data["guid"] = d["guid"]
                    data["uniqueId"] = d["uniqueId"]
            return data
        except:
            return None
    
    @property
    def attributes(self):
        try:
            key = OPTION["attribute"]
            if self._data_json != None and self.has_key(self._data_json, key) and self._data_json[key] != None:
                return self._data_json[key]
            else:
                return []
        except:
            return []
    
    @property
    def devices(self):
        try:
            key = OPTION["device"]
            if self._data_json != None and self.has_key(self._data_json, key) and self._data_json[key] != None:
                return self._data_json[key]
            else:
                return []
        except:
            return []
    
    @property
    def rules(self):
        try:
            key = OPTION["rule"]
            if self._data_json != None and self.has_key(self._data_json, key) and self._data_json[key] != None:
                return self._data_json[key]
            else:
                return []
        except:
            return []
    
    @property
    def protocol(self):
        try:
            key = OPTION["protocol"]
            if self._data_json != None and self.has_key(self._data_json, key) and self._data_json[key] != None:
                return self._data_json[key]
            else:
                return None
        except:
            return None
    
    def __enter__(self):
        return self
    
    def __exit__(self, exception_type, exception_value, traceback):
        try:
            for attr in self.attributes:
                if self.has_key(attr, "evaluation"):
                    attr["evaluation"].destroyed()
                    del attr["evaluation"]
            
            if self._client and hasattr(self._client, 'Disconnect'):
                self._client.Disconnect()
            
        except Exception as ex:
            print("IoTConnectSDK Exit : ", ex.message)
    
    def __init__(self, cpId, uniqueId, scopeId, listner, env="PROD"):
        try:
            self._lock = threading.Lock()
            self.get_config()

            if self._config == None:
                raise Exception("SDK Configration not found!")
            
            self.get_properties()
            self._offlineClient = offlineclient(self._config, self.send_offline_msg_to_broker)
            
            if cpId == None or cpId == "":
                raise Exception("CPID not found!")

            if uniqueId == None or uniqueId == "":
                raise Exception("Unique Id not found!")
            
            if scopeId == None or scopeId == "":
                raise Exception("Scope Id not found!")
            
            self._cpId = cpId
            self._uniqueId = uniqueId
            self._config["scope_id"] = scopeId
            self._config["device_id"] = str(cpId + "-" + uniqueId)
            self._config["env"] = env

            self._ruleEval = RuleEvaluation(self.send_rule_data, self.command_sender)
            
            if listner != None:
                self.listner_callback = listner
            
            self._base_url = self.get_base_url(self._cpId)
            if self._base_url != None:
                self.process_sync("all")
            else:
                raise Exception("Base Url not found!")
        except Exception as ex:
            raise Exception("IoTConnectSDK : " + ex.message)
