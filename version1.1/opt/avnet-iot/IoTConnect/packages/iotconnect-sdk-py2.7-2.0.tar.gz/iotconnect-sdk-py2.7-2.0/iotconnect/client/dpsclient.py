import os
import ssl as ssl
import json
import time
import threading
from provisioning_device_client import *
from iothub_client import *

authType = {
    "TPM": 4
}

DPSMSGTYPE = {
    "DEVICE_CREATED": 9,
    "DEVICE_CONNECTED": 10
}

class dpsclient:
    _auth_type = None
    _config = None
    _sdk_config = None
    _isConnected = False
    _client = None
    _reg_status = None
    _iot_hub_url = None
    _device_id = None
    _connection_status = None
    _send_status = None
    _send_offline_status = None
    _onMessage = None
    _onMessageSend = None
    _thread = None
    
    def register_status_callback(self, reg_status, user_context):
        try:
            #print(reg_status)
            pass
        except Exception as ex:
            print("register_status_callback : " + ex.message)

    def register_device_callback(self, register_result, iothub_uri, device_id, user_context):
        try:
            self._reg_status = register_result
            self._iot_hub_url = iothub_uri
            self._device_id = device_id
        except Exception as ex:
            print("register_device_callback : " + ex.message)
    
    def connection_status_callback(self, result, reason, user_context):
        try:
            self._connection_status = result
            if self._connection_status == IoTHubConnectionStatus.AUTHENTICATED:
                self._isConnected = True
            else:
                self._isConnected = False
            #self.event_call("MSG_SEND","onMessageSend",[DPSMSGTYPE["DEVICE_CREATED"], { "deviceId" : self._device_id, "iothubName" : self._iot_hub_url, "status": 1 if self.isConnected else 0 }])
        except Exception as ex:
            print("connection_status_callback : " + ex.message)
    
    def send_confirmation_callback(self, message, result, user_context):
        try:
            self._send_status = result
        except Exception as ex:
            print("send_confirmation_callback : " + ex.message)
    
    def send_offline_confirmation_callback(self, message, result, user_context):
        try:
            self._send_offline_status = result
        except Exception as ex:
            print("send_confirmation_callback : " + ex.message)
    
    def receive_message_callback(self, message, counter):
        try:
            message_buffer = message.get_bytearray()
            size = len(message_buffer)
            data = message_buffer[:size].decode('utf-8')
            msg = json.loads(data)
            if self._onMessage != None:
                self._onMessage(msg)
            return IoTHubMessageDispositionResult.ACCEPTED
        except Exception as ex:
            print("receive_message_callback : " + ex.message)
            return IoTHubMessageDispositionResult.ABANDONED
    
    def Disconnect(self):
        try:
            if self._client != None:
                self._client = None
        except Exception as ex:
            print("Disconnect : " + ex.message)
    
    def Send(self, data):
        try:
            if self._isConnected == False:
                self._send_status = None
                return False
            
            message = IoTHubMessage(json.dumps(data))
            self._client.send_event_async(message, self.send_confirmation_callback, None)
            
            while self._send_status == None and self._isConnected == True:
                time.sleep(0.1)
            
            if self._send_status == IoTHubClientConfirmationResult.OK:
                self._send_status = None
                return True
            else:
                self._send_status = None
                return False
        except Exception as ex:
            print("Send : " + ex.message)
            self._send_status = False
            return False
    
    def SendOfflineData(self, data):
        try:
            if self._isConnected == False:
                self._send_offline_status = None
                return False
            
            message = IoTHubMessage(json.dumps(data))
            self._client.send_event_async(message, self.send_offline_confirmation_callback, None)
            
            #time.sleep(0.5)
            while self._send_offline_status == None and self._isConnected == True:
                time.sleep(0.1)
            
            if self._send_offline_status == IoTHubClientConfirmationResult.OK:
                self._send_offline_status = None
                return True
            else:
                self._send_offline_status = None
                return False
        except Exception as ex:
            print("Send Offline Data: " + ex.message)
            self._send_offline_status = False
            return False
    
    def _init_provisioning_client(self, registration_id):
        provisioning_client = None
        try:
            global_prov_url = str(self._sdk_config["api_global_prov_url"])
            scope_id = self.scope_id

            provisioning_client = ProvisioningDeviceClient(global_prov_url, scope_id, ProvisioningSecurityDeviceType.TPM, ProvisioningTransportProvider.HTTP)
            provisioning_client.set_option("registration_id", registration_id)
            try:
                provisioning_client.register_device(self.register_device_callback, None, self.register_status_callback, None)
            except Exception as ex:
                self._reg_status = ProvisioningDeviceResult.ERROR
                print("TPM not found!")
            
            while self._reg_status == None:
                time.sleep(0.5)
            
            provisioning_client = None
            if self._reg_status == ProvisioningDeviceResult.OK and self._iot_hub_url != None and self._device_id != None:
                return True
            else:
                print("Device registration failed...")
                return False
        except Exception as ex:
            print("Provisioning Client Init : " + ex.message)
            provisioning_client = None
            return False
        
    def _init_dps(self):
        try:
            if self._client != None:
                self._client = None
            
            if self._init_provisioning_client(self.registration_id):
                self._client = IoTHubClient(self._iot_hub_url, self._device_id, IoTHubSecurityType.SAS, IoTHubTransportProvider.MQTT)
                self._client.set_option("messageTimeout", 1)
                self._client.set_option("keepalive", 60)
                #self._client.set_option("logtrace", 1)
                self._client.set_connection_status_callback(self.connection_status_callback, 0)
                self._client.set_retry_policy(IoTHubClientRetryPolicy.RETRY_INTERVAL, 0)
                self._client.set_message_callback(self.receive_message_callback, 0)
            
            if self._client != None:
                while self._connection_status == None:
                    time.sleep(0.5)
                
                if self._connection_status == IoTHubConnectionStatus.AUTHENTICATED:
                    self.event_call("MSG_SEND","onMessageSend",[DPSMSGTYPE["DEVICE_CREATED"], { "deviceId" : self._device_id, "iothubName" : self._iot_hub_url, "status": 1 }])
            
        except Exception as ex:
            print("DPS Init : " + ex.message)
    
    def ResetConfig(self, auth_type, config):
        try:
            self._auth_type = auth_type
            self._config = config
            if self._config == None:
                raise Exception("Protocol Configration not found!")
            
            self._init_dps()
        except Exception as ex:
            print("ReConnect : " + ex.message)
    
    def event_call(self, name, taget, arg):
        try:
            if self._thread != None:
                self._thread = None

            self._thread = threading.Thread(
                target=getattr(self, taget), args=arg)
            self._thread.daemon = True
            self._thread.setName(name)
            self._thread.start()
        except Exception as ex:
            print("event_call : " + ex.message)
    
    def onMessageSend(self, message_type, data):
        try:
            time.sleep(0.5)
            if self._onMessageSend != None:
                self._onMessageSend(message_type, data)
        except Exception as ex:
            print("event_call : " + ex.message)
    
    @property
    def isConnected(self):
        return self._isConnected
    
    @property
    def name(self):
        return "dps"

    @property
    def scope_id(self):
        return str(self._sdk_config["scope_id"])
    
    @property
    def registration_id(self):
        return str(self._sdk_config["device_id"]).lower()
    
    def __init__(self, auth_type, config, sdk_config, onMessage, onMessageSend):
        try:
            self._auth_type = auth_type
            self._config = config
            self._sdk_config = sdk_config
            self._onMessage = onMessage
            self._onMessageSend = onMessageSend
            
            if self._config == None:
                raise Exception("Protocol Configration not found!")

            if self._sdk_config == None:
                raise Exception("SDK Configration not found!")

            if self.scope_id == None or self.scope_id == "":
                raise Exception("Scope Id not found!")
            
            if self.registration_id == None or self.registration_id == "":
                raise Exception("Registration Id not found!")
            
            self._init_dps()
        except Exception as ex:
            print("DPS Client Init : " + ex.message)
