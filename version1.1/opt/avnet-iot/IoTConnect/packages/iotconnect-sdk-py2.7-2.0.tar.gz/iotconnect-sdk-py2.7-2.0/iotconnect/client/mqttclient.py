import os
import ssl as ssl
import paho.mqtt.client as mqtt
import json
import time

authType = {
	"KEY": 1,
	"CA_SIGNED": 2,
	"CA_SELF_SIGNED": 3
}

class mqttclient:
    _name = None
    _auth_type = None
    _sdk_config = None
    _config = None
    _subTopic = None
    _pubTopic = None
    _client = None
    _keepalive = 60
    _onMessage = None
    _isConnected = False
    _connected_flag = False
    _mqtt_status = {
        0: "MQTT: Connection successful",
        1: "MQTT: Connection refused - incorrect protocol version",
        2: "MQTT: Connection refused - invalid client identifier",
        3: "MQTT: Connection refused - server unavailable",
        4: "MQTT: Connection refused - bad username or password",
        5: "MQTT: Connection refused - not authorised"
    }
    
    def _on_connect(self, mqtt_self, client, userdata, rc):
        try:
            if rc != 0:
                raise RuntimeError(self._mqtt_status[rc])
            
            self._isConnected = True
        except Exception as ex:
            print(ex.message)

    def _on_disconnect(self, client, userdata, rc):
        try:
            self._isConnected = False
        except Exception as ex:
            print("_on_disconnect : " + ex.message)

    def _on_log(self, client, userdata, level, buf):
        try:
            if level != mqtt.MQTT_LOG_DEBUG:
                print("MQTT Log : " + buf)
        except Exception as ex:
            print("_on_log : " + ex.message)
    
    def _on_message(self, client, userdatam, msg):
        try:
            msg = json.loads(msg.payload)
            if self._onMessage != None:
                self._onMessage(msg)
            
        except Exception as ex:
            print("_on_message : " + ex.message)
    
    def _connect(self):
        try:
            if self._isConnected == False:
                self._client.connect(self._config["h"], self._config["p"], self._keepalive)
                if self._subTopic != None:
                    self._client.subscribe(self._subTopic)
                self._client.loop_start()
        except Exception as ex:
            print("_connect : " + ex.message)
    
    def Disconnect(self):
        try:
            if self._client != None and self._isConnected == True:
                self._client.disconnect()
                while self._isConnected == True:
                    time.sleep(1)
                self._client.loop_stop()
                self._client = None
        except Exception as ex:
            print("Disconnect : " + ex.message)

    def Send(self, data):
        try:
            _obj = None
            if self._isConnected:
                if self._client and self._pubTopic != None:
                    _obj = self._client.publish(self._pubTopic, payload=json.dumps(data), qos=1)
            
            #print("\nSend : " + json.dumps(data) + "\n")
            #if _obj and _obj.rc == 0:
            #    print("publish data sucessfully...\n")

            if _obj and _obj.rc == 0:
                return True
            else:
                return False
        except Exception as ex:
            print("Send : " + ex.message)
            return False

    def _init_mqtt(self):
        try:
            if self._client != None:
                self._client.disconnect()
                while self._isConnected == True:
                    time.sleep(1)
                self._client.loop_stop()
                self._client = None

            self._client = mqtt.Client(client_id=self._config['id'], clean_session=True, userdata=None, protocol=mqtt.MQTTv311)

            #Check Auth Type
            if self._auth_type == authType["KEY"]:
                self._client.username_pw_set(self._config["un"], self._config["pwd"])                
                #self._client.tls_set(ca_certs = self._sdk_config["SSLCaPath"], tls_version = ssl.PROTOCOL_TLSv1)
                self._client.tls_set(ca_certs = None, tls_version = ssl.PROTOCOL_TLSv1)
            elif self._auth_type == authType["CA_SIGNED"]:
                self._client.username_pw_set(self._config["un"], password=None)
                self._client.tls_set(ca_certs=None, certfile=self._sdk_config["SSLCertPath"], keyfile=self._sdk_config["SSLKeyPath"], cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLSv1_2, ciphers=None)
            elif self._auth_type == authType["CA_SELF_SIGNED"]:
                self._client.username_pw_set(self._config["un"], password=None)
                self._client.tls_set(ca_certs=None, certfile=self._sdk_config["SSLCertPath"], keyfile=self._sdk_config["SSLKeyPath"], cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLSv1_2, ciphers=None)
            
            self._client.on_connect = self._on_connect
            self._client.on_disconnect = self._on_disconnect
            #self._client.on_log = self._on_log
            self._client.on_message = self._on_message
            
            if self._client != None:
                self._connect()

        except Exception as ex:
            print("MQTT Init : " + ex.message)

    def ResetConfig(self, auth_type, config):
        try:
            self._auth_type = auth_type
            self._config = config
            if self._config == None:
                raise Exception("Protocol Configration not found!")

            self._subTopic = config['sub'].encode('ascii', 'ignore')
            self._pubTopic = config['pub'].encode('ascii', 'ignore')
            self._init_mqtt()
        except Exception as ex:
            print("ReConnect : " + ex.message)

    @property
    def isConnected(self):
        return self._isConnected

    @property
    def name(self):
        return self._config["n"]

    def __init__(self, auth_type, config, sdk_config, onMessage):
        try:
            self._auth_type = auth_type
            self._config = config
            self._sdk_config = sdk_config
            self._onMessage = onMessage
            
            if self._config == None:
                raise Exception("Protocol Configration not found!")

            if self._sdk_config == None:
                raise Exception("SDK Configration not found!")
            
            self._subTopic = config['sub'].encode('ascii', 'ignore')
            self._pubTopic = config['pub'].encode('ascii', 'ignore')

            self._init_mqtt()
        except Exception as ex:
            print("MQTT Client Init : " + ex.message)
