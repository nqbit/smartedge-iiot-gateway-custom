import sys, os
import json
import threading

class offlineclient:
    _data_path = ""
    _sdk_config = None
    _lock = False
    _thread = None
    
    def Send(self, data):
        try:
            _data = json.dumps(data) + "\n"
            if self._data_path:
                with open(self._data_path, "a") as dfile:
                    dfile.write(_data)
        except Exception as ex:
            print("publish_offline : " + ex.message)
    
    def data_exist(self):
        try:
            return os.path.exists(self._data_path) == True and os.stat(self._data_path).st_size != 0
        except Exception as ex:
            return False
    
    def divide_chunks(self, l, n):
        # looping till length l
        for i in range(0, len(l), n):
            yield l[i:i + n]
    
    def read_chunks(self, chunk):
        rows = []
        for obj in chunk:
            try:
                if len(obj) > 0:
                    rows.append(json.loads(obj))
            except:
                print("Faulty data : " + obj)
        return rows
    
    def send_back_to_client(self):
        try:
            _data = None
            with open(self._data_path, "r") as dfile:
                _data = dfile.read()
            
            if _data == None or _data == "":
                self._thread = None
                return
            
            with open(self._data_path, "w") as dfile:
                dfile.write("")
            
            if _data != None:
                _data = _data.split("\n")
            
            chunks = list(self.divide_chunks(_data, 10))
            _rData = []
            if len(chunks) > 0:
                for chunk in chunks:
                    rows = self.read_chunks(chunk)
                    if len(rows) > 0:
                        for row in rows:
                            if self.sendBackToClient(row) == False:
                                _rData.append(row)
            
            _fData = ""
            _list = []
            if len(_rData) > 0:
                for obj in _rData:
                    _list.append(json.dumps(obj))
                _fData = "\n".join(_list)
                with open(self._data_path, "a") as dfile:
                    dfile.write(_fData)
            self._thread = None
        except Exception as ex:
            print("send_back_to_client : " + ex.message)
            self._thread = None
    
    def PublishData(self):
        try:
            if self._thread == None and self.data_exist():
                self.event_call("PUBDATA", "send_back_to_client",())
        except Exception as ex:
            print("PublishData : ", ex.message)
    
    def event_call(self, name, taget, arg):
        try:
            self._thread = threading.Thread(target=getattr(self, taget), args=arg)
            self._thread.daemon = True
            self._thread.setName(name)
            self._thread.start()
        except Exception as ex:
            print("event_call : " + ex.message)
    
    def __init__(self, sdk_config, sendBackToClient):
        try:
            self._sdk_config = sdk_config
            
            if self._sdk_config == None:
                raise Exception("SDK Configration not found!")
            
            self._data_path = os.path.join(sys.path[0], 'sensor_data.txt')

            #self._data_path = os.path.abspath(os.path.dirname(__file__) + "/../") + "\\data.txt"
            self.sendBackToClient = sendBackToClient
        except Exception as ex:
            print("Offline Client Init : " + ex.message)
