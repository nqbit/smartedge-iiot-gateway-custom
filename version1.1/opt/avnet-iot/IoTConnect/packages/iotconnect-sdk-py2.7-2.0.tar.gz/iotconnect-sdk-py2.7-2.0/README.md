# Softweb Solutions Inc
## IOT Connect SDK : Software Development Kit 1.0.0

**Prerequisite tools:**

1. Python : Python version 2.7.12 and compatible

**Installation :** 

1. Download the "iotconnect-sdk-py2.7-2.0.tar.gz"

2. Goto directory path using terminal/Command prompt
    - pip install iotconnect-sdk-py2.7-2.0.tar.gz

3. Ready to go:
    
    //This script can send the data to given input(uniqueid, cpid) device by command prompt
    - python example.js <<env>> //Environment DEV, QA, POC, PROD (Default if not supply the environment argument)
    
**Usage :**

Import library
```python
from iotconnect import IoTConnectSDK
```

Prerequisite input data *
```python
uniqueId = <<uniqueId>>
cpid = <<CPID>> 
env = <<env>> // DEV, QA, POC, PROD(Default)
```

To get the device information and connect to the device
```python
sdk = IoTConnectSDK(cpid, uniqueId, callbackMessage, env)
```

To receive the command from Cloud to Device(C2D) 
```python
def callbackMessage(msg):
    print "\n"
    print msg["ack"]
    print msg["ackId"]
    print msg["command"]
    print msg["uniqueId"]
```

Data input format
```python
var sendTeledata = [{
    "uniqueId": "123456",
    "time" : '2018-05-24T10:06:17.857Z', //Date format should be as defined
    "data": {
        "temperature": 15.55,
        "humidity" : 27.97,
        "weight" : 36,
        "gyroscope" : {
            'x' : -1.2,
            'y' : 0.25,
            'z' : 1.1,
        }
    }
}];
```

To send the data from Device To Cloud(D2C)
```python
sdk.SendData(sendTeledata)
```