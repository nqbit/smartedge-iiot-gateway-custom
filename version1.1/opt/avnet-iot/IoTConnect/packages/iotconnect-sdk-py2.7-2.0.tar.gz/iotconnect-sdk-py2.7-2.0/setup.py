import os
import sys
from setuptools import setup

setup(
    name="iotconnect-sdk-py2.7",
    version="2.0",
    python_requires='~=2.7',
    description='IOT Connect DPS version 2.0',
    packages=["iotconnect", "iotconnect.client", "iotconnect.common"],
    install_requires=["paho-mqtt","wheel","azure-iot-provisioning-device-client","azure-iothub-device-client"],
    package_data={'iotconnect': ['assets/*.*']},
    platforms=['Linux', 'Mac OS X', 'Win'],
    zip_safe=False,
    classifiers=[
        "Programming Language :: Python :: 2.7",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ],
)